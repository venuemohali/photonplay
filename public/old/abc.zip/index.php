<?php

require __DIR__.'/../photonplay/bootstrap/app.php';


$app->run();


?>